<?php 
 
 $con = mysqli_connect("localhost","root","","tour") or die("Couldn't connect");

?>